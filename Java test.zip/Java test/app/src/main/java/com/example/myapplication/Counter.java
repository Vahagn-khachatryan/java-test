package com.example.myapplication;

public class Counter {
    public static int count;

}
