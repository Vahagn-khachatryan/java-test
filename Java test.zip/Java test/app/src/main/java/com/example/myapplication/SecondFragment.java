package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;


/**
 * A simple {@link Fragment} subclass.
 */
public class SecondFragment extends Fragment {
Button b2;
CheckBox c8;
    public SecondFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_second, container, false);
        b2=v.findViewById(R.id.button2);
        c8=v.findViewById(R.id.checkBox8);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (c8.isChecked())
                {
                    Counter.count++;
                }
                Fragment3 Fragment3=new Fragment3();
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                transaction.replace(R.id.mainActivity, Fragment3).commit();
            }
        });
        return v;
    }
}
