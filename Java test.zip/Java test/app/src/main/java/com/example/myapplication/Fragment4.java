package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment4 extends Fragment {
Button b4;
CheckBox c13, c15;
    public Fragment4() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_4, container, false);
        b4=v.findViewById(R.id.button4);
        c15=v.findViewById(R.id.checkBox15);
        c13=v.findViewById(R.id.checkBox13);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (c13.isChecked() && c15.isChecked()){
                    Counter.count++;
                }
                Fragment5 Fragment5=new Fragment5();
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                transaction.replace(R.id.mainActivity, Fragment5).commit();
            }
        });
        return v;
    }
}
