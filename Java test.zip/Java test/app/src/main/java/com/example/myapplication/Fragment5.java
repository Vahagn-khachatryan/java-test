package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment5 extends Fragment {
  //  CheckBox c1,c2, c3, c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14, c15,c16, c17, c18, c19, c20;
  // TextView t;
Button b5;
CheckBox c19;
    public Fragment5() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_5, container, false);
        //CheckBox c=v.findViewById(R.id.checkBox20);

        b5=v.findViewById(R.id.b5);
        c19=v.findViewById(R.id.checkBox19);

        b5.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
if (c19.isChecked())
{
    Counter.count++;
}
                LastFragment LastFragment=new LastFragment();
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                transaction.replace( R.id.mainActivity, LastFragment).commit();

            }
        });
        return v;
    }

    }




